import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Inject } from '@angular/core';
import { MovieComponent } from './movie.component';
import { HttpClientTestingModule} from '@angular/common/http/testing'
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserDynamicTestingModule} from '@angular/platform-browser-dynamic/testing'
import { Movie } from '../models/movie';
// import { DynamicTestModule} from '@angular/platform-browser-dynamic/testing';
xdescribe('MovieComponent', () => {
  let component: MovieComponent;
  let fixture: ComponentFixture<MovieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MovieComponent,],
      imports: [HttpClientTestingModule, RouterTestingModule, BrowserDynamicTestingModule ],
      // providers:[Movie]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
