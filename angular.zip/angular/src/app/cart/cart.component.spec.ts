import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CartComponent } from './cart.component';
import { HttpClientTestingModule} from '@angular/common/http/testing'
import { CartService } from '../services/cart.service';
import { of, throwError } from 'rxjs';
describe('CartComponent', () => {
  let component: CartComponent;
  let fixture: ComponentFixture<CartComponent>;
  let cartService = CartService

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CartComponent],
      imports :[HttpClientTestingModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call calculateSubtotal..', ()=>{
    component.cartItem=[]
    let spy =spyOn(component, 'calculateSubtotal').and.callThrough();
    component.calculateSubtotal();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
  it('should call removeItem..', ()=>{
    // component.cartItem=[{}]
    // let service = fixture.debugElement.injector.get(cartService);
    // spyOn(service, 'deleteCart').and.callFake(()=>{
    //   return of({
    //     statusCode:200
    //   })
    // })
    let spy =spyOn(component, 'removeItem').and.callThrough();
    component.removeItem(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call incrementQuantity..', ()=>{
    // component.cartItem=[{}]
    // let service = fixture.debugElement.injector.get(cartService);
    // spyOn(service, 'deleteCart').and.returnValue(throwError({status:422}))
    //   return of({
    //     statusCode:200
    //   })
    // })
    let spy =spyOn(component, 'incrementQuantity').and.callThrough();
    component.incrementQuantity(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call decrementQuantity..', ()=>{
    // component.cartItem=[{}]
    // let service = fixture.debugElement.injector.get(cartService);
    // spyOn(service, 'deleteCart').and.callFake(()=>{
    //   return of({
    //     statusCode:200
    //   })
    // })
    let spy =spyOn(component, 'decrementQuantity').and.callThrough();
    component.decrementQuantity(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
});
