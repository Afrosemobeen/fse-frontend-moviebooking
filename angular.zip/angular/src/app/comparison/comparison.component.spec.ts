import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComparisonComponent } from './comparison.component';

describe('ComparisonComponent', () => {
  let component: ComparisonComponent;
  let fixture: ComponentFixture<ComparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ComparisonComponent],
      imports :[HttpClientTestingModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call removeItem..', ()=>{
    // component.cartItem=[{}]
    // let service = fixture.debugElement.injector.get(cartService);
    // spyOn(service, 'deleteCart').and.callFake(()=>{
    //   return of({
    //     statusCode:200
    //   })
    // })
    let spy =spyOn(component, 'removeItem').and.callThrough();
    component.removeItem(2);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

});
