export class Mobile {
    constructor(
        public id: string,
        public mobile: string,
        public features: string,
        public price: string,
        public img: string,
        public quantity?: Number) { }
}




